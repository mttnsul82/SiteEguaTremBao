-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: restaurante_egua_trem_bao
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'f01b7aee-c3db-11f0-bbdf-d09466e73791:1-49';

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `preco` decimal(10,2) NOT NULL,
  `id_categoria` int DEFAULT NULL,
  PRIMARY KEY (`id_produto`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Café da Manhã da Casa','Pão de queijo, bolo de fubá e café',69.90,1),(2,'Manhã Leve','Tapioca, frutas e café',59.90,1),(3,'Frango com Quiabo','Frango com quiabo, arroz branco e angu',34.90,2),(4,'Costelinha na Brasa','Costelinha com barbecue mineiro',42.90,2),(5,'Vaca Atolada','Costela bovina com mandioca',39.90,2),(6,'Bambá Mineiro','Caldo de couve com torresmo',32.90,2),(7,'Galinhada da Orla','Galinhada com couve e queijo',36.90,2),(8,'Pato no Tucupi','Prato típico paraense',49.90,2),(9,'Maniçoba da Casa','Maniçoba com arroz branco',44.90,2),(10,'Vatapá','Vatapá cremoso servido com arroz',37.90,2),(11,'Tacacá','Caldo paraense com jambu',22.90,2),(12,'Arroz Paraense','Acompanhamento',9.90,3),(13,'Mandioca/Aipim','Acompanhamento',9.90,3),(14,'Farofa Mineira','Acompanhamento',9.90,3),(15,'Torresmo','Acompanhamento',9.90,3),(16,'Angu','Acompanhamento',9.90,3),(17,'Farinha Paraense','Acompanhamento',9.90,3),(18,'Doce Encontro Brasileiro','Queijo com goiabada',19.90,4),(19,'Rabanada Tropical','Rabanada com doce de leite',21.90,4),(20,'Açaí Tradicional','Açaí paraense',16.90,4),(21,'Tropical Carioca','Açaí com frutas',18.90,4),(22,'Gateau da Casa','Petit gâteau com sorvete',16.90,4),(23,'Clássicos da Casa','Doces variados',24.90,4);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-10 15:16:00
